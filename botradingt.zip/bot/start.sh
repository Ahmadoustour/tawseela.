#!/bin/sh
pip install --no-cache-dir -r requirements.txt
python bot.py
